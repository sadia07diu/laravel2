@extends("master")
@section("title")
    Home
@endsection
@section("body")
    <h1 class="text-center text-success font-weight-bold">hello bitm</h1>
@endsection
